def accountable_recommendation_handler(user_id, item_id):
    log_request(user_id, item_id, timestamp=now())
    
    if is_sensitive_resource(item_id):
        if not access_approval_granted(user_id):
            deny_request()
            log_violation(user_id, item_id)
            return None
        else:
            log_approval(user_id, item_id)
    
    recommendation_list = get_recommendations(user_id)
    log_response(user_id, recommendation_list, model_version="v1.2.3")
    
    return recommendation_list
